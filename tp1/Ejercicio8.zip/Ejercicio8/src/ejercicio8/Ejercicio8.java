/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio8;

import java.util.Scanner;

/**
 *
 * @author claudio
 */
public class Ejercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num1, num2, resultado;
        double numa, numb, resultadoDouble;
        System.out.println("Ingrese primer entero");
        num1 = Integer.parseInt(input.nextLine() );
        System.out.println("Ingrese segundo entero");
        num2 = Integer.parseInt(input.nextLine() );
        resultado = num1 / num2;
        System.out.println("Ingrese primer double");
        numa = Double.parseDouble(input.nextLine() );
        System.out.println("Ingrese segundo double");
        numb = Double.parseDouble(input.nextLine() );
        resultadoDouble = numa / numb;
        System.out.println(resultado);
        System.out.println(resultadoDouble);
        
    }
    
}
