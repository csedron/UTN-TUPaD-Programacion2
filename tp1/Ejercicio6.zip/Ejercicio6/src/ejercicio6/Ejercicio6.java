/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio6;

import java.util.Scanner;

/**
 *
 * @author claudio
 */
public class Ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String nombre, direccion, comillas;
        int edad;
        System.out.println("Ingresa su nombre");
        nombre = input.nextLine();
        System.out.println("Ingresa edad");
        edad = Integer.parseInt(input.nextLine());
        System.out.println("Ingresa su direccion");
        direccion = input.nextLine();
        comillas = "\"" + direccion + "\"";
        System.out.println("Nombre: " + nombre + "\n" + "Edad: " + edad + " años" + "\n" + "Direccion: " + comillas);
        
    }
    
}
