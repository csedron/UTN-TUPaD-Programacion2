/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio5;

import java.util.Scanner;

/**
 *
 * @author claudio
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int v1, v2, suma, resta, producto;
        double division;
        System.out.println("Ingresa primer valor");
        v1 = Integer.parseInt(input.nextLine());
        System.out.println("Ingresa segundo valor");
        v2 = Integer.parseInt(input.nextLine());
        suma = v1 + v2;
        resta = v1 - v2;
        producto = v1 * v2;
        division = ( (double) v1 / v2);
        System.out.println("La suma de los dos valores introducidos es: "+ suma);
        System.out.println("La resta de los dos valores introducidos es: "+ resta);
        System.out.println("La amultiplicacion de los dos valores introducidos es: "+ producto);
        System.out.println("La division de los dos valores introducidos es: "+ division);
    }
    
}
