/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio4;

import java.util.Scanner;

/**
 *
 * @author claudio sedron
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /* Escribe un programa que solicite al usuario ingresar su nombre y edad, y luego
        los muestre en pantalla. Usa Scanner para capturar los datos */
        Scanner input = new Scanner(System.in);
        String nombre;
        int edad;
        System.out.println("Ingresa tu edad");
        edad = Integer.parseInt(input.nextLine());
        System.out.println("Ingresa tu nombre");
        nombre = input.nextLine();
        System.out.println("Te llamas " + nombre + ", y tenes " + edad);
        
        
    }
    
}
